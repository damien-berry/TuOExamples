# Introduction
The purpose of this project is to demonstrate how to set up TuO as an Idp for a Blazor WASM Client 

# Getting Started
dependancies

1. Dot Net 6
2. Visual Studio 2022 

# Build and Test
1. Open VS 2022
2. set TuoClientsideBlazorExample.Server.csproj as the startup project
3. run the application