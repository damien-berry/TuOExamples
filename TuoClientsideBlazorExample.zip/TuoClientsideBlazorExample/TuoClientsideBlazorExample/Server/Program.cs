using Microsoft.AspNetCore.Authentication.JwtBearer;

var builder = WebApplication.CreateBuilder(args);

//<script src="_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"></script>
//the above script needs to be added in the index.html for the security to work

// This is where we set up the configuration to validate the token passed through to the API
// the BaseAddressAuthorizationMessageHandler adds the token in the client side blazor code
// https://docs.microsoft.com/en-us/aspnet/core/blazor/security/webassembly/additional-scenarios?view=aspnetcore-6.0
// authorisation on the identity is configured below
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options => {      
        options.TokenValidationParameters.ValidIssuer = "https://www.uat.auth.qld.gov.au/auth/realms/tell-us-once";
        options.TokenValidationParameters.ValidAudience = "sample-BlazorSample";
        options.Authority = "https://www.uat.auth.qld.gov.au/auth/realms/tell-us-once";
        }
    );

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
}
else
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseBlazorFrameworkFiles();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
// add policies here to undertake authorisation
// with this call it allows us to use the standard [Authorize] attribute in the WeatherForecastController
// with policies you can set up authorisation on roles or claims like [Authorize(Policy = Policies.IsAdmin)]
// https://docs.microsoft.com/en-us/aspnet/core/security/authorization/policies?view=aspnetcore-6.0
app.UseAuthorization(); 
app.MapRazorPages();
app.MapControllers();
app.MapFallbackToFile("index.html");

app.Run();
